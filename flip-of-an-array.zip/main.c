/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//an array of integers arr[] of size n, the task is to flip the array of elements in a cyclic order of position//
#include <stdio.h>

int main()
{
    int arr[]={1,2,3,4,5,6};
    int d=3;
    int n= sizeof(arr)/sizeof(arr[0]);
    for(int i=0;i<d;i++)
    {
        int f=arr[0];
        for(int j=0;j<n;j++)
        {
            arr[j]=arr[j+1];
        }
        arr[n-1]=f;
    }
    for(int i=0;i<n;i++)
    {
        printf("%d",arr[i]);
    }
    
}
